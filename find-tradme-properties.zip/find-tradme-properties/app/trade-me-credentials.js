var trademe = {
	credentials: {
		oauth_consumer_key:'7D0287693DD82832C3037F118EFBE44F',
		oauth_signature:'6C67C229DFBB5C8807FFEA1EDCCA40A5' + '&'
	}
}