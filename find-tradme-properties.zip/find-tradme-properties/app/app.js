'use strict';

// Declare app level module which depends on views, and components
angular.module('myTradeMeApp', [
  'ngRoute',
  'myTradeMeApp.localityView',
  'myTradeMeApp.propertiesView'
]).
config(['$routeProvider', function($routeProvider) {
  $routeProvider.otherwise({redirectTo: '/where'});
}]);
