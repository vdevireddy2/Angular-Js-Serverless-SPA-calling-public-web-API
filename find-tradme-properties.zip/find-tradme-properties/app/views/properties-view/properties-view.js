'use strict';

angular.module('myTradeMeApp.propertiesView', ['ngRoute', 'tradeMeServices'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/look-in/:regionName/:regionId', {
    templateUrl: 'views/properties-view/properties-view.html',
    controller: 'PropertiesViewController'
  });
}])

.controller('PropertiesViewController', ['$scope', '$routeParams', 'PropertiesByRegion', function($scope, $routeParams, PropertiesByRegion) {
	
	var maxPrice = 0, 
		minPrice = 0,
		minBeds = 0,
		maxBeds = 0;

	var properties = PropertiesByRegion.query({region: $routeParams.regionId});
	$scope.properties = properties;	
	$scope.bedrooms = 1;
	$scope.suburb = '';
	
	$scope.regionId = $routeParams.regionId;
}])

