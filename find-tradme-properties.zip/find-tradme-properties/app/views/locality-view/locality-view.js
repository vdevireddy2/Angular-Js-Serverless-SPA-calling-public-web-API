'use strict';

angular.module('myTradeMeApp.localityView', ['ngRoute', 'tradeMeServices'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/where', {
    templateUrl: 'views/locality-view/locality-view.html',
    controller: 'LocalityViewController'
  });
}])

.controller('LocalityViewController', ['$scope', 'Localities', function($scope, Localities) {
	$scope.localities = Localities.query();
}]);